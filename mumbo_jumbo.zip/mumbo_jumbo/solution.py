# %%
MODEL_OUT = "final_model.pth"
SUBMISSION_OUT = "submission.csv"

# %%
import os
import torch
import pandas as pd

# Load the historical dataset
df = pd.read_csv("data/history_data.csv")
print(f"Historical dataset shape: {df.shape}")

# Extract MNIST pixel features (784 dimensions)
pixel_cols = [f"pixel_{i}" for i in range(28*28)]
X = torch.tensor(df[pixel_cols].values, dtype=torch.float32)

# Extract prediction logits (10 dimensions) from original model
logit_cols = [f"pred_logit_{i}" for i in range(10)]
target_logits = torch.tensor(df[logit_cols].values, dtype=torch.float32)

true_labels = torch.tensor(df["true_label"].values, dtype=torch.long)
print(f"Loaded {X.shape[0]} images. Features X shape: {X.shape} | Logits shape: {target_logits.shape}")
# %%
pieces_dir = "data/pieces"
piece_files = [f for f in os.listdir(pieces_dir) if f.endswith(".pth")]

proj_layer = None
last_layer = None
inp_pieces = []
out_pieces = []



for i, filename in enumerate(piece_files):
    path = f"data/pieces/{filename}"
    obj = torch.load(path, map_location="cpu")
    weight = obj['weight']
    bias = obj['bias']

    if weight.shape == (16, 784):
        proj_layer = {'filename': filename, 'weight': weight, 'bias': bias}
    elif weight.shape == (10, 16):
        last_layer={'filename': filename, 'weight': weight, 'bias': bias}
    elif weight.shape == (32, 16):
        inp_pieces.append({'filename': filename, 'weight': weight, 'bias': bias})
    elif weight.shape == (16, 32):
        out_pieces.append({'filename': filename, 'weight': weight, 'bias': bias})


print(f"Isolated Components:")
print(f"  - Front Projection Piece (`proj`): {proj_layer['filename']}")
print(f"  - Output Classification Piece (`last`): {last_layer['filename']}")
print(f"  - Input Block projections ($W_{{in}}$): {len(inp_pieces)} pieces")
print(f"  - Output Block projections ($W_{{out}}$): {len(out_pieces)} pieces")
# %%
def evaluate_reconstruction(ordered_blocks):
    """
    Evaluates the Logits MSE of a candidate reassembled model.

    Arguments:
        ordered_blocks: A list of dictionaries representing the 32 blocks in proposed order.
                        Each block must contain 'inp_weight', 'inp_bias', 'out_weight', 'out_bias'.
    Returns:
        float: Logits MSE against target predictions.
    """
    curr_x = X.clone()
    # Front projection layer (784 -> 16)
    curr_x = curr_x @ proj_layer['weight'].t() + proj_layer['bias']

    # Forward pass through ordered blocks
    for b in ordered_blocks:
        w_in, b_in = b['inp_weight'], b['inp_bias']
        w_out, b_out = b['out_weight'], b['out_bias']
        curr_x = curr_x + torch.relu(curr_x @ w_in.t() + b_in) @ w_out.t() + b_out

    # Output layer (16 -> 10 logits)
    logits = curr_x @ last_layer['weight'].t() + last_layer['bias']

    mse = torch.mean((logits - target_logits) ** 2).item()
    return mse
# %% [markdown]
# # The following code defines the optimization procedure to find the correct order of the blocks. It uses a stochastic search approach with various move types to explore the space of possible arrangements.
# %%
import random

random.seed(42)

indices = list(range(32))
random.shuffle(indices)

arbitrary_latent_module = []

for i in indices:
    arbitrary_latent_module.append(inp_pieces[i])
    arbitrary_latent_module.append(out_pieces[i])
# %%
def build_ordered_blocks(arbitrary_latent_module):
    """

    :param arbitrary_latent_module:
    :return: resnet blocks in with same order
    """
    ordered_blocks = []

    for i in range(0, len(arbitrary_latent_module), 2):
        inp = arbitrary_latent_module[i]
        out = arbitrary_latent_module[i + 1]

        ordered_blocks.append({
            "inp_weight": inp["weight"],
            "inp_bias": inp["bias"],
            "out_weight": out["weight"],
            "out_bias": out["bias"],
        })

    return ordered_blocks
# %%
import copy
import random

def optimize_blocks(
    module,
    evaluate_mse,
    seed=42,
):
    """
    arranges layers , logic is described in report
    """
    random.seed(seed)

    current = copy.deepcopy(module)

    best_mse = evaluate_mse(
        build_ordered_blocks(current)
    )

    print("initial mse:", best_mse)

    total_iters = 25000

    for step in range(total_iters):

        candidate = copy.deepcopy(current)

        # ----------------------------------
        # Phase 1: 0 - 14999
        # swap_in, swap_out, swap_block
        # ----------------------------------
        if step < 15000:

            move = random.choice([
                "swap_in",
                "swap_out",
                "swap_block",
            ])


        else:

            move = random.choice([
                "swap_block",
                "swap_two_block",
            ])

        if move == "swap_in":

            b1, b2 = random.sample(range(32), 2)

            i1 = 2 * b1
            i2 = 2 * b2

            candidate[i1], candidate[i2] = (
                candidate[i2],
                candidate[i1]
            )

        elif move == "swap_out":

            b1, b2 = random.sample(range(32), 2)

            i1 = 2 * b1 + 1
            i2 = 2 * b2 + 1

            candidate[i1], candidate[i2] = (
                candidate[i2],
                candidate[i1]
            )

        elif move == "swap_block":

            b1, b2 = random.sample(range(32), 2)

            s1 = 2 * b1
            s2 = 2 * b2

            candidate[s1:s1+2], candidate[s2:s2+2] = (
                candidate[s2:s2+2],
                candidate[s1:s1+2]
            )

        else:  # swap_two_blocks

            b1, b2, b3, b4 = random.sample(range(32), 4)

            s1 = 2 * b1
            s2 = 2 * b2

            candidate[s1:s1+2], candidate[s2:s2+2] = (
                candidate[s2:s2+2],
                candidate[s1:s1+2]
            )

            s3 = 2 * b3
            s4 = 2 * b4

            candidate[s3:s3+2], candidate[s4:s4+2] = (
                candidate[s4:s4+2],
                candidate[s3:s3+2]
            )

        mse = evaluate_mse(
            build_ordered_blocks(candidate)
        )

        if mse < best_mse:

            current = candidate
            best_mse = mse

            print(
                f"iter={step:5d} "
                f"move={move:15s} "
                f"mse={best_mse:.8f}"
            )

            if best_mse <= 1e-8:
                print(
                    f"\nPerfect solution found "
                    f"at iteration {step}"
                )
                return current, best_mse

    return current, best_mse
# %% [markdown]
#  Below block is run on a seed which is tested to give 0 mse, i have tested for a number of seeds most of them give 0 mse. but in code not i have proposed a solution to get exact sequence
# %%
seq2,mse=optimize_blocks(
    arbitrary_latent_module,
    evaluate_reconstruction,
    seed=1
)
# %% [markdown]
# ## Following code defines the final model architecture and loading mechanism to verify the solution and save the final model and submission csv.
# %%
import torch.nn as nn
class ResBlock(nn.Module):
    """x -> x + W_out @ relu(W_in @ x + b_in) + b_out"""

    def __init__(self, dim=16, hidden=32):
        super().__init__()
        self.inp = nn.Linear(dim, hidden)
        self.out = nn.Linear(hidden, dim)

    def forward(self, x):
        return x + self.out(torch.relu(self.inp(x)))


class ReassembledResNet(nn.Module):
    """Proper module form of the reassembled network: proj -> 32 ResBlocks -> last."""

    def __init__(self, num_blocks=32, in_dim=784, hidden_dim=16, mid_dim=32, num_classes=10):
        super().__init__()
        self.proj = nn.Linear(in_dim, hidden_dim)
        self.blocks = nn.ModuleList(ResBlock(hidden_dim, mid_dim) for _ in range(num_blocks))
        self.last = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.proj(x)
        for block in self.blocks:
            x = block(x)
        return self.last(x)

    @torch.no_grad()
    def load_pieces(self, proj_layer, last_layer, ordered_blocks):
        self.proj.weight.copy_(proj_layer["weight"])
        self.proj.bias.copy_(proj_layer["bias"])
        self.last.weight.copy_(last_layer["weight"])
        self.last.bias.copy_(last_layer["bias"])
        for block, b in zip(self.blocks, ordered_blocks):
            block.inp.weight.copy_(b["inp_weight"])
            block.inp.bias.copy_(b["inp_bias"])
            block.out.weight.copy_(b["out_weight"])
            block.out.bias.copy_(b["out_bias"])

# %%
def create_submission_csv(best_module, output_path=SUBMISSION_OUT):
    """
    :param best_module: list of layers of projections
    :return: csv file at output_path
    """
    rows = []
    for block_idx in range(len(best_module) // 2):
        inp = best_module[2 * block_idx]
        out = best_module[2 * block_idx + 1]
        rows.append({
            "block_index": block_idx,
            "inp_piece": inp["filename"],
            "out_piece": out["filename"],
        })
    submission = pd.DataFrame(rows)
    submission.to_csv(output_path, index=False)
    return submission
# %%
ordered_blocks=build_ordered_blocks(seq2)
# %%
## model verification
model = ReassembledResNet()
model.load_pieces(proj_layer, last_layer, ordered_blocks)
model.eval()

with torch.no_grad():
    check_mse = torch.mean((model(X) - target_logits) ** 2).item()
print(f"Final model forward-pass MSE: {check_mse:.8f}")

torch.save({
    "state_dict": model.state_dict(),
    "architecture": "ReassembledResNet",
    "config": {"num_blocks": 32, "in_dim": 784, "hidden_dim": 16, "mid_dim": 32, "num_classes": 10},
    "mse": check_mse,
}, MODEL_OUT)
print(f"Saved {MODEL_OUT}")

create_submission_csv(seq2, SUBMISSION_OUT)
print(f"Saved {SUBMISSION_OUT}")